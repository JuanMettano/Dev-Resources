---
name: wp-fluid-page-styles
description: Genera el sistema de estilos base para una nueva pagina de WordPress -- paleta primaria y paleta secundaria a partir del logo (siempre mostradas primero como muestras visuales con HEX y RGB, antes de cualquier CSS), escala tipografica fluida (h1-h5, body, span, button), clases de margin/padding para hero containers y contenedores normales, y clases principales de color y botones, todo usando CSS clamp() que escala de forma fluida y exacta entre 600px y 1200px de viewport. Usa este skill siempre que el usuario mencione crear una nueva pagina de WordPress, de un logo para un desarrollo nuevo, definir colores de marca o del logo, paletas de color, tipografia responsive/fluida, clamp(), o clases de margin/padding para hero/container, incluso si no lo pide explicitamente con esas palabras -- por ejemplo "necesito los estilos para esta pagina nueva", "sacame los colores del logo", "toma este logo como referente", "dame opciones de paleta", "cuadrame las fuentes de este proyecto" o "dame los margenes del hero".
---

# Sistema de estilos fluidos para paginas de WordPress

Este skill encapsula un flujo de trabajo que el usuario (desarrollador WordPress)
ya probo y le funciona bien para arrancar paginas nuevas rapido y con un sistema
visual consistente. Tiene cuatro partes que casi siempre se piden juntas al
iniciar un proyecto: colores, tipografia, margenes/paddings de contenedores y
clases principales. No inventes un enfoque distinto -- el valor de este skill es
la repetibilidad, asi que sigue esta misma logica en cada proyecto, ajustando
solo los numeros.

## Orden obligatorio cuando el usuario da un logo

Cuando el usuario comparte un logo (para sacar colores o como referente de todo
el desarrollo), la respuesta SIEMPRE sigue este orden:

1. **Primero los colores, de forma visual**: el widget de la seccion "Plantilla
   visual de paletas" con la Paleta primaria y las opciones de Paleta secundaria.
   Nunca entregues colores solo como lista de hex ni solo dentro del CSS.
2. **Despues la tabla de tamanos** (tipografia y contenedores) con los valores
   min/max usados.
3. **Al final el CSS** (archivo .css y/o bloque de codigo).

Si el usuario pide "todo de una vez" (ej. "toma este logo como referente para
crear todo"), no te detengas a esperar su eleccion: elige la opcion secundaria
mas versatil, marcala en el widget con `tag:"En el CSS"` (y la primaria
tambien), muestra el widget primero en esa misma respuesta y luego entrega la
tabla y el CSS. Las opciones no elegidas quedan con el boton para cambiar.
Cada vez que regeneres el CSS por un cambio de colores, vuelve a mostrar el
widget actualizado antes del CSS.

## Regla de oro del escalado (no negociable)

Todo clamp() que entregue este skill debe:

- Valer **exactamente su minimo en 600px** de viewport y por debajo.
- Valer **exactamente su maximo en 1200px** de viewport y por encima.
- Crecer de forma lineal entre 600px y 1200px.

Solo usa otros viewports si el usuario lo pide explicitamente para ese proyecto.

Para garantizarlo:

1. **La parte base del termino preferido va en px, no en rem** (ej.
   `clamp(56px, 4vw + 32px, 80px)`). Con rem, la escala depende del font-size
   raiz del `html`: si el theme o Elementor usa `html { font-size: 62.5% }`
   (10px), los puntos de quiebre se desplazan y un h1 o el body pueden llegar a
   su maximo en ~1300-2300px en vez de 1200px. Este fue un bug real del skill.
   Solo usa `--unit rem` si el usuario lo pide, y en ese caso preguntale el
   font-size raiz del proyecto y pasalo con `--root`.
2. **No redondees los coeficientes a 2 decimales.** El script usa 4 decimales;
   con 2 decimales el punto de quiebre se corre (ej. body llegaba a 18px en
   1218px). Copia los valores tal cual salen del script.
3. **Nunca calcules un clamp() a mano.** Siempre usa el script y revisa que cada
   fila diga `OK`. Si alguna dice `ERROR` o el script termina con codigo 1, no
   entregues ese CSS: corrige la entrada y vuelve a correrlo.

## El script

Usa `scripts/clamp_calculator.py` incluido en este skill. Antes de usarlo,
confirma que es la version actual: `python3 scripts/clamp_calculator.py --help`
debe mostrar la opcion `--check` y el default `600`. Si no (version vieja con
default 750 o rem), escribe el script de la seccion "Codigo del script" al final
de este archivo en tu directorio de trabajo y usa ese.

```bash
# Un solo valor
python3 clamp_calculator.py --min 56 --max 80

# Varios de una vez (recomendado para toda la hoja)
python3 clamp_calculator.py --batch valores.json

# Auditar un clamp() que ya existe en el proyecto (ej. heredado o de otra fuente)
python3 clamp_calculator.py --check "clamp(56px, 1rem + 5.33vw, 80px)" --root 10
```

`valores.json` es una lista de `{"name": ..., "min": ..., "max": ...}`. Usa
`--important` si el CSS convive con estilos inyectados por un page builder como
Elementor. Cada fila imprime el clamp() y una linea de verificacion del tipo
`OK: 56px en 600.0px · 80px en 1200.0px`.

Si el usuario pega CSS existente y pregunta si escala bien, pasa cada clamp() por
`--check` (con el font-size raiz real del proyecto) y reporta en que viewport
alcanza su min y su max.

## Antes de empezar: identifica que necesita el usuario

El usuario puede pedir todo junto (proyecto nuevo desde cero, normalmente con un
logo) o solo una parte (ej. "ya tengo los colores, dame solo las fuentes").
Si da un logo sin mas detalles, asume que quiere todo.

Si no da tamanos, usa estos defaults y dilo en una linea para que pueda
ajustarlos: h1 max 64px, body 16-18px, hero 100px vertical / 40px lateral.

## Parte 1 -- Paleta primaria y paleta secundaria

1. Si el usuario menciona un logo pero no lo ha adjuntado, pidele la imagen
   antes de continuar -- no hay forma confiable de adivinar los colores de marca.
2. Con el logo, identifica los colores de marca (el isotipo/wordmark, no el
   fondo si es blanco/transparente). Extrae el hex exacto de los pixeles de la
   imagen (ej. con Pillow, agrupando por tono) en vez de estimarlo a ojo.
3. Arma siempre dos tipos de paleta, con estos nombres exactos:
   - **Paleta primaria**: los colores del logo y sus variaciones (Primario
     (logo), Primario oscuro, Primario claro, Fondo suave). Si el logo tiene
     varios colores, todos van aqui. Es una sola.
   - **Paleta secundaria**: colores que acompanan a la primaria, derivados con
     teoria del color. Propone 2-3 opciones, nombradas "Paleta secundaria ·
     Opcion 1", "Paleta secundaria · Opcion 2", etc., cada una con un criterio
     distinto (neutros de marca, analoga, complementaria...) y 2-5 colores con
     rol (Texto oscuro, Secundario, Acento, Fondo, Hover...).
   No uses otros nombres como "Paleta A/B/C".
4. Muestralas con la herramienta de widgets visuales inline (`show_widget`;
   llama antes a su `read_me`) usando la plantilla de la seccion "Plantilla
   visual de paletas". Solo cambia el arreglo `PALETTES`. Cada color aparece
   como un bloque grande y debajo su rol, su variable CSS (si ya esta en el
   CSS), su HEX y su RGB; el bloque muestra "Aa" con el ratio de contraste
   WCAG contra blanco o negro. Al hacer clic se copia el HEX.
   Si la herramienta de widgets no esta disponible, genera la misma plantilla
   como archivo .html completo y enviala al usuario como archivo.
5. En el texto debajo del widget, explica en 1 linea por opcion secundaria su
   criterio y para que sirve. No repitas la lista de hex en el texto.
6. Advierte en una linea si un color de marca no da contraste suficiente con
   texto blanco (menos de 4.5:1 para texto normal) y propone el tono mas oscuro
   para texto o botones.
7. Si el usuario ya tiene los colores definidos, usalos y no insistas en el logo
   (muestralos igual en el widget como Paleta primaria).
8. En el CSS, los colores van como variables en `:root` con el mismo nombre que
   muestra el widget (ej. `--color-primary`, `--color-accent`,
   `--color-text`, `--color-bg-light`, `--color-accent-hover`). Ajusta los
   nombres si el proyecto usa otra convencion (Elementor, theme.json, etc.).

## Parte 2 -- Tipografia fluida (h1-h5, body, span, button)

El usuario normalmente solo da el maximo de h1 (ej. "el h1 llega a 80px") y
espera que el resto se derive de ahi. Sigue este criterio, y siempre muestra la
tabla resultante:

- **Maximos de h2-h5**: escala modular, cada nivel entre 75% y 80% del anterior
  (h2 = h1*0.78, h3 = h2*0.78, etc.). Redondea a numeros limpios.
- **Minimos de cada heading**: los titulos grandes escalan mas (ratio min/max
  ~70-75% en h1) y los pequenos casi no (~85-90% en h5). Interpola entre h1 y h5
  en vez de usar la misma proporcion para todos.
- **body, span y button**: mismo rango que body (el usuario suele darlo, ej.
  "16px a 18px"). Solo cambia span o button si lo pide explicitamente.
- Confirma el orden min/max si hay ambiguedad (¿18px es el maximo o el minimo?).

### Ejemplo (para ver el patron, no para copiar los numeros)

Dado h1 max = 80px, body = 16-18px:

| Elemento | Min (600px) | Max (1200px) |
|---|---|---|
| h1 | 56px | 80px |
| h2 | 46px | 62px |
| h3 | 38px | 48px |
| h4 | 31px | 37px |
| h5 | 26px | 29px |
| body/span/button | 16px | 18px |

Salida verificada del script:

```css
h1    { font-size: clamp(56px, 4vw + 32px, 80px); }
h2    { font-size: clamp(46px, 2.6667vw + 30px, 62px); }
h3    { font-size: clamp(38px, 1.6667vw + 28px, 48px); }
h4    { font-size: clamp(31px, 1vw + 25px, 37px); }
h5    { font-size: clamp(26px, 0.5vw + 23px, 29px); }
body, span, button { font-size: clamp(16px, 0.3333vw + 14px, 18px); }
```

## Parte 3 -- Margin y padding: hero vs contenedor normal

El usuario usa dos niveles de espaciado, como margin o como padding segun el
proyecto (el calculo es identico; si no dijo cual, entrega ambos: la clase base
con margin y una variante `--padding`):

- **Hero container**: el bloque principal arriba de la pagina, con mas aire.
- **Container normal**: el resto de las secciones, mas discreto.

El usuario normalmente da el maximo vertical y horizontal del hero (ej. "100px
arriba/abajo, 40px a los lados"). Deriva el resto asi:

- **Minimos del hero**: si no los da, ~40-45% del maximo.
- **Container normal**: si no los da, ~50-60% de los maximos del hero.

Cada eje (vertical y horizontal) es una fila separada en el batch. Ejemplo
verificado (hero 45-100 / 18-40, container 28-60 / 12-24):

```css
.hero-container    { margin: clamp(45px, 9.1667vw - 10px, 100px) clamp(18px, 3.6667vw - 4px, 40px); }
.content-container { margin: clamp(28px, 5.3333vw - 4px, 60px) clamp(12px, 2vw, 24px); }
```

Ajusta los nombres de clase a la convencion del proyecto (Elementor, Bricks,
Gutenberg/theme.json, o CSS plano).

## Parte 4 -- Clases principales

Con los colores elegidos, genera clases utilitarias basicas que usen las
variables (nunca hex sueltos):

- Texto: `.text-primary`, `.text-accent` (usa el tono oscuro/hover si el
  acento no contrasta bien como texto), `.text-muted`, `.text-white`.
- Fondos: `.bg-primary` (con texto blanco), `.bg-primary-soft`, `.bg-light`,
  `.bg-warm`.
- Botones: `.btn-primary` (color de acento + `:hover` con el tono hover) y
  `.btn-secondary` (borde del primario, se rellena en hover).
- Detalles opcionales con los colores restantes del logo (ej. divisor,
  badge).

## Entregable final (en este orden)

1. **Widget visual de colores** (Parte 1), con lo usado en el CSS marcado con
   `tag:"En el CSS"`.
2. Tabla resumen de tamanos con columnas "Min (600px)" y "Max (1200px)".
3. El CSS final, agrupado por seccion (colores, tipografia, contenedores,
   clases principales), copiado tal cual de la salida del script. Entregalo
   como archivo `.css` con el nombre del proyecto.
4. Una linea confirmando que todos los clamp pasaron la verificacion (min en
   600px, max en 1200px), y que valores asumiste si el usuario no los dio.
5. Si trabaja con un page builder (Elementor, Bricks), menciona brevemente donde
   pegar cada cosa.

## Plantilla visual de paletas

Usala tal cual en `show_widget` (o dentro de un .html completo como respaldo).
Edita solo el arreglo `PALETTES`; los hex deben ir en formato `#RRGGBB`.
- `pick:true` en cada opcion secundaria (muestra boton para cambiar a ella).
- `tag:"En el CSS"` en las paletas usadas en el CSS (borde resaltado, sin boton).
- `v:"--color-..."` en cada color que ya tiene variable CSS (opcional).

```html
<h2 class="sr-only">Paleta primaria del logo y opciones de paleta secundaria, con muestra visual, HEX y RGB de cada color.</h2>
<style>
.pw{font-family:var(--font-sans);color:var(--text-primary)}
.pw-pal{border:1px solid var(--border);border-radius:var(--radius,12px);padding:14px;margin-bottom:12px}
.pw-pal.sel{border:2px solid var(--border-accent)}
.pw-head{display:flex;justify-content:space-between;align-items:baseline;gap:8px;margin-bottom:10px;flex-wrap:wrap}
.pw-title{font-weight:600;font-size:15px}
.pw-tag{font-size:11px;font-weight:600;padding:2px 8px;border-radius:999px;border:1px solid var(--border-accent);color:var(--text-accent);margin-left:6px}
.pw-desc{font-size:12px;color:var(--text-secondary)}
.pw-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px}
.pw-sw{cursor:pointer;border:none;background:none;padding:0;text-align:left;font:inherit;color:inherit}
.pw-chip{height:84px;border-radius:8px;border:1px solid var(--border);display:flex;align-items:flex-end;justify-content:flex-end;padding:6px;font-size:11px;font-weight:600}
.pw-name{font-size:12px;font-weight:600;margin-top:6px}
.pw-var{font-family:var(--font-mono);font-size:11px;color:var(--text-secondary)}
.pw-hex{font-family:var(--font-mono);font-size:12px}
.pw-rgb{font-family:var(--font-mono);font-size:11px;color:var(--text-secondary)}
.pw-strip{display:flex;height:10px;border-radius:5px;overflow:hidden;margin-top:12px}
.pw-btn{margin-top:10px;font:inherit;font-size:12px;padding:6px 12px;border-radius:8px;border:1px solid var(--border);background:transparent;color:var(--text-primary);cursor:pointer}
.pw-btn:hover{border-color:var(--border-accent)}
.pw-toast{font-size:12px;color:var(--text-secondary);min-height:16px}
</style>
<div class="pw" id="pw"></div>
<div class="pw-toast" id="pw-toast"></div>
<script>
/* EDITAR SOLO ESTE BLOQUE. Primero la Paleta primaria (pick:false), luego cada opcion de Paleta secundaria (pick:true) */
const PALETTES = [
  {name:"Paleta primaria", desc:"Colores extraídos del logo", pick:false, tag:"En el CSS", colors:[
    {role:"Primario (logo)", hex:"#1A5FB4", v:"--color-primary"},{role:"Primario oscuro", hex:"#0F3A6E", v:"--color-primary-dark"},{role:"Fondo suave", hex:"#EEF4FB", v:"--color-primary-soft"}]},
  {name:"Paleta secundaria · Opción 1", desc:"Neutros de marca: textos y fondos", pick:true, tag:"En el CSS", colors:[
    {role:"Texto oscuro", hex:"#0C2D4D", v:"--color-text"},{role:"Fondo claro", hex:"#F3F7FA", v:"--color-bg-light"}]},
  {name:"Paleta secundaria · Opción 2", desc:"Complementaria: contraste para CTAs", pick:true, colors:[
    {role:"Secundario", hex:"#F2A33A"},{role:"Acento", hex:"#D9622B"},{role:"Fondo", hex:"#FFF6EA"}]}
];
/* ---------------------------------------------------------------- */
const rgb=h=>{h=h.replace('#','');return[0,2,4].map(i=>parseInt(h.substr(i,2),16))};
const lum=c=>{const a=rgb(c).map(v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});return .2126*a[0]+.7152*a[1]+.0722*a[2]};
const contrast=(a,b)=>{const x=lum(a),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)};
const root=document.getElementById('pw'),toast=document.getElementById('pw-toast');
PALETTES.forEach(p=>{
  const d=document.createElement('div');d.className='pw-pal'+(p.tag?' sel':'');
  d.innerHTML=`<div class="pw-head"><span class="pw-title">${p.name}${p.tag?`<span class="pw-tag">${p.tag}</span>`:''}</span><span class="pw-desc">${p.desc}</span></div><div class="pw-row"></div><div class="pw-strip">${p.colors.map(c=>`<span style="flex:1;background:${c.hex}"></span>`).join('')}</div>`;
  const row=d.querySelector('.pw-row');
  p.colors.forEach(c=>{
    const [r,g,b]=rgb(c.hex);const w=contrast(c.hex,'#FFFFFF'),k=contrast(c.hex,'#000000');
    const txt=w>=k?'#FFFFFF':'#000000',ratio=Math.max(w,k).toFixed(1);
    const s=document.createElement('button');s.className='pw-sw';s.title='Copiar HEX';
    s.innerHTML=`<div class="pw-chip" style="background:${c.hex};color:${txt}">Aa ${ratio}:1</div><div class="pw-name">${c.role}</div>${c.v?`<div class="pw-var">${c.v}</div>`:''}<div class="pw-hex">${c.hex.toUpperCase()}</div><div class="pw-rgb">rgb(${r}, ${g}, ${b})</div>`;
    s.onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(c.hex.toUpperCase());toast.textContent=`Copiado ${c.hex.toUpperCase()}`;};
    row.appendChild(s);
  });
  if(p.pick&&!p.tag){const btn=document.createElement('button');btn.className='pw-btn';btn.textContent='Cambiar a esta paleta secundaria';
  btn.onclick=()=>sendPrompt(`Cambia la paleta secundaria a la ${p.name}: ${p.colors.map(c=>c.role+' '+c.hex).join(', ')} y regenera el CSS`);
  d.appendChild(btn);}
  root.appendChild(d);
});
</script>
```

## Codigo del script

Si `scripts/clamp_calculator.py` falta o es una version vieja, escribe esto en
`clamp_calculator.py` y usalo:

```python
#!/usr/bin/env python3
"""
clamp_calculator.py — Genera valores CSS clamp() para escalado fluido
entre dos viewports (por defecto 600px y 1200px) y VERIFICA que cada
clamp() alcance su minimo exactamente en min-vp y su maximo en max-vp.

Por defecto la parte base se expresa en px, no en rem: asi la escala NO
depende del font-size raiz (html) del theme/page builder. Con rem, si el
proyecto usa html { font-size: 62.5% } (10px), los puntos de quiebre se
desplazan (un h1 puede llegar a su maximo en ~2000px en vez de 1200px).

Uso individual:
    python3 clamp_calculator.py --min 56 --max 80
    python3 clamp_calculator.py --min 56 --max 80 --min-vp 600 --max-vp 1200

Uso por lotes:
    python3 clamp_calculator.py --batch valores.json

valores.json:
    [
        {"name": "h1", "min": 56, "max": 80},
        {"name": "hero-margin-y", "min": 45, "max": 100}
    ]

Para cada fila imprime el clamp() y una linea de verificacion con el
viewport real donde se alcanza el min y el max. Si alguno se desvia mas de
1px del objetivo, termina con codigo de error 1.

Solo verificar un clamp existente (por ejemplo, uno que vino de otro lado):
    python3 clamp_calculator.py --check "clamp(56px, 1rem + 5.33vw, 80px)" --root 16
"""

import argparse
import json
import re
import sys

DECIMALS = 4  # suficiente para que el error en el viewport sea < 1px


def clamp_parts(min_px, max_px, min_vp, max_vp):
    if max_vp <= min_vp:
        raise ValueError("max_vp debe ser mayor que min_vp")
    if max_px < min_px:
        raise ValueError(f"max ({max_px}) es menor que min ({min_px}); revisa el orden")
    slope = (max_px - min_px) / (max_vp - min_vp)
    intercept_px = min_px - slope * min_vp
    return round(intercept_px, DECIMALS), round(slope * 100, DECIMALS)


def clamp_css(min_px, max_px, min_vp=600, max_vp=1200, unit="px", root=16):
    base_px, vw = clamp_parts(min_px, max_px, min_vp, max_vp)
    if unit == "px":
        base = f"{_fmt(base_px)}px"
    elif unit == "rem":
        base = f"{_fmt(round(base_px / root, DECIMALS))}rem"
    else:
        raise ValueError("unit debe ser 'px' o 'rem'")
    sign = "-" if base.startswith("-") else "+"
    if vw == 0:
        return f"{_fmt(min_px)}px"
    if base_px == 0:
        return f"clamp({_fmt(min_px)}px, {_fmt(vw)}vw, {_fmt(max_px)}px)"
    return f"clamp({_fmt(min_px)}px, {_fmt(vw)}vw {sign} {base.lstrip('-')}, {_fmt(max_px)}px)"


def reached_at(css, root=16):
    """Viewport (px) donde el clamp alcanza su min y su max, leyendo el CSS tal cual."""
    m = re.match(r"\s*clamp\(\s*([-\d.]+)px\s*,\s*(.+?)\s*,\s*([-\d.]+)px\s*\)", css)
    if not m:
        return None
    mn, pref, mx = float(m.group(1)), m.group(2), float(m.group(3))
    base, vw = 0.0, 0.0
    for sign, num, u in re.findall(r"([+-]?)\s*([\d.]+)\s*(px|rem|vw)", pref):
        v = float(num) * (-1 if sign == "-" else 1)
        if u == "vw":
            vw += v
        elif u == "rem":
            base += v * root
        else:
            base += v
    if vw == 0:
        return None
    k = vw / 100
    return (mn - base) / k, (mx - base) / k


def _fmt(value):
    s = f"{value:.{DECIMALS}f}".rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def main():
    p = argparse.ArgumentParser(description="Genera y verifica clamp() CSS para escalado fluido.")
    p.add_argument("--min", type=float)
    p.add_argument("--max", type=float)
    p.add_argument("--min-vp", type=float, default=600, help="Viewport minimo (default 600)")
    p.add_argument("--max-vp", type=float, default=1200, help="Viewport maximo (default 1200)")
    p.add_argument("--unit", choices=["px", "rem"], default="px",
                   help="Unidad de la parte base (default px; rem depende del font-size raiz)")
    p.add_argument("--root", type=float, default=16, help="font-size raiz en px, solo para rem/--check")
    p.add_argument("--important", action="store_true")
    p.add_argument("--batch", type=str)
    p.add_argument("--check", type=str, help="Verifica un clamp() existente")
    a = p.parse_args()
    suffix = " !important" if a.important else ""

    if a.check:
        r = reached_at(a.check, a.root)
        if not r:
            sys.exit("No pude interpretar ese clamp()")
        print(f"min alcanzado en {r[0]:.1f}px, max alcanzado en {r[1]:.1f}px (root {a.root:g}px)")
        return 0

    rows = []
    if a.batch:
        with open(a.batch) as f:
            rows = json.load(f)
    elif a.min is not None and a.max is not None:
        rows = [{"name": "", "min": a.min, "max": a.max}]
    else:
        p.error("Pasa --min y --max, --batch archivo.json, o --check 'clamp(...)'")

    failed = False
    for row in rows:
        min_vp = row.get("min_vp", a.min_vp)
        max_vp = row.get("max_vp", a.max_vp)
        css = clamp_css(row["min"], row["max"], min_vp, max_vp, row.get("unit", a.unit), a.root)
        name = row.get("name", "")
        print(f"{name + ': ' if name else ''}{css}{suffix}")
        r = reached_at(css, a.root)
        if r:
            ok = abs(r[0] - min_vp) <= 1 and abs(r[1] - max_vp) <= 1
            failed |= not ok
            print(f"   {'OK' if ok else 'ERROR'}: {row['min']:g}px en {r[0]:.1f}px · "
                  f"{row['max']:g}px en {r[1]:.1f}px")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
```
