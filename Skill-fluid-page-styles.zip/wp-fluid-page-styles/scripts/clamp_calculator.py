#!/usr/bin/env python3
"""
clamp_calculator.py — Genera valores CSS clamp() para escalado fluido
entre dos viewports (por defecto 600px y 1200px) y VERIFICA que cada
clamp() alcance su minimo exactamente en min-vp y su maximo en max-vp.

Por defecto la parte base se expresa en px, no en rem: asi la escala NO
depende del font-size raiz (html) del theme/page builder. Con rem, si el
proyecto usa html { font-size: 62.5% } (10px), los puntos de quiebre se
desplazan (un h1 puede llegar a su maximo en ~2000px en vez de 1200px).

Uso individual:
    python3 clamp_calculator.py --min 56 --max 80
    python3 clamp_calculator.py --min 56 --max 80 --min-vp 600 --max-vp 1200

Uso por lotes:
    python3 clamp_calculator.py --batch valores.json

valores.json:
    [
        {"name": "h1", "min": 56, "max": 80},
        {"name": "hero-margin-y", "min": 45, "max": 100}
    ]

Para cada fila imprime el clamp() y una linea de verificacion con el
viewport real donde se alcanza el min y el max. Si alguno se desvia mas de
1px del objetivo, termina con codigo de error 1.

Solo verificar un clamp existente (por ejemplo, uno que vino de otro lado):
    python3 clamp_calculator.py --check "clamp(56px, 1rem + 5.33vw, 80px)" --root 16
"""

import argparse
import json
import re
import sys

DECIMALS = 4  # suficiente para que el error en el viewport sea < 1px


def clamp_parts(min_px, max_px, min_vp, max_vp):
    if max_vp <= min_vp:
        raise ValueError("max_vp debe ser mayor que min_vp")
    if max_px < min_px:
        raise ValueError(f"max ({max_px}) es menor que min ({min_px}); revisa el orden")
    slope = (max_px - min_px) / (max_vp - min_vp)
    intercept_px = min_px - slope * min_vp
    return round(intercept_px, DECIMALS), round(slope * 100, DECIMALS)


def clamp_css(min_px, max_px, min_vp=600, max_vp=1200, unit="px", root=16):
    base_px, vw = clamp_parts(min_px, max_px, min_vp, max_vp)
    if unit == "px":
        base = f"{_fmt(base_px)}px"
    elif unit == "rem":
        base = f"{_fmt(round(base_px / root, DECIMALS))}rem"
    else:
        raise ValueError("unit debe ser 'px' o 'rem'")
    sign = "-" if base.startswith("-") else "+"
    if vw == 0:
        return f"{_fmt(min_px)}px"
    if base_px == 0:
        return f"clamp({_fmt(min_px)}px, {_fmt(vw)}vw, {_fmt(max_px)}px)"
    return f"clamp({_fmt(min_px)}px, {_fmt(vw)}vw {sign} {base.lstrip('-')}, {_fmt(max_px)}px)"


def reached_at(css, root=16):
    """Viewport (px) donde el clamp alcanza su min y su max, leyendo el CSS tal cual."""
    m = re.match(r"\s*clamp\(\s*([-\d.]+)px\s*,\s*(.+?)\s*,\s*([-\d.]+)px\s*\)", css)
    if not m:
        return None
    mn, pref, mx = float(m.group(1)), m.group(2), float(m.group(3))
    base, vw = 0.0, 0.0
    for sign, num, u in re.findall(r"([+-]?)\s*([\d.]+)\s*(px|rem|vw)", pref):
        v = float(num) * (-1 if sign == "-" else 1)
        if u == "vw":
            vw += v
        elif u == "rem":
            base += v * root
        else:
            base += v
    if vw == 0:
        return None
    k = vw / 100
    return (mn - base) / k, (mx - base) / k


def _fmt(value):
    s = f"{value:.{DECIMALS}f}".rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def main():
    p = argparse.ArgumentParser(description="Genera y verifica clamp() CSS para escalado fluido.")
    p.add_argument("--min", type=float)
    p.add_argument("--max", type=float)
    p.add_argument("--min-vp", type=float, default=600, help="Viewport minimo (default 600)")
    p.add_argument("--max-vp", type=float, default=1200, help="Viewport maximo (default 1200)")
    p.add_argument("--unit", choices=["px", "rem"], default="px",
                   help="Unidad de la parte base (default px; rem depende del font-size raiz)")
    p.add_argument("--root", type=float, default=16, help="font-size raiz en px, solo para rem/--check")
    p.add_argument("--important", action="store_true")
    p.add_argument("--batch", type=str)
    p.add_argument("--check", type=str, help="Verifica un clamp() existente")
    a = p.parse_args()
    suffix = " !important" if a.important else ""

    if a.check:
        r = reached_at(a.check, a.root)
        if not r:
            sys.exit("No pude interpretar ese clamp()")
        print(f"min alcanzado en {r[0]:.1f}px, max alcanzado en {r[1]:.1f}px (root {a.root:g}px)")
        return 0

    rows = []
    if a.batch:
        with open(a.batch) as f:
            rows = json.load(f)
    elif a.min is not None and a.max is not None:
        rows = [{"name": "", "min": a.min, "max": a.max}]
    else:
        p.error("Pasa --min y --max, --batch archivo.json, o --check 'clamp(...)'")

    failed = False
    for row in rows:
        min_vp = row.get("min_vp", a.min_vp)
        max_vp = row.get("max_vp", a.max_vp)
        css = clamp_css(row["min"], row["max"], min_vp, max_vp, row.get("unit", a.unit), a.root)
        name = row.get("name", "")
        print(f"{name + ': ' if name else ''}{css}{suffix}")
        r = reached_at(css, a.root)
        if r:
            ok = abs(r[0] - min_vp) <= 1 and abs(r[1] - max_vp) <= 1
            failed |= not ok
            print(f"   {'OK' if ok else 'ERROR'}: {row['min']:g}px en {r[0]:.1f}px · "
                  f"{row['max']:g}px en {r[1]:.1f}px")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
